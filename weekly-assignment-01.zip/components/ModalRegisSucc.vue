<template>
    <fragment>
        <h3>Registration Success!</h3> <hr>
        <div class="row" style="text-align: left;">
            <div class="col-4">
                <p style="padding-left: 8%;">Full Name </p>
            </div>
            <div class="col-8">
                <p style="padding-left: 2%; font-size: 13pt;">: {{ props.fName + " " + props.lName}}</p>
            </div>
        </div>

        <div class="row" style="text-align: left;">
            <div class="col-4">
                <p style="padding-left: 8%;">Email </p>
            </div>
            <div class="col-8">
                <p style="padding-left: 2%; font-size: 13pt;">: {{ props.email }}</p>
            </div>
        </div>

        <div class="row" style="text-align: left;">
            <div class="col-4">
                <p style="padding-left: 8%;">Phone Number </p>
            </div>
            <div class="col-8">
                <p style="padding-left: 2%; font-size: 13pt;">: {{ props.noHP }}</p>
            </div>
        </div>
        
        <!-- <b-button class="mt-3" variant="outline-danger" block @click="hideModal">Close</b-button> -->
    </fragment>
</template>

<script>
export default {
    name: "ModalRegis",
    props: {
        fName: {
            type: String,
            default: ''
        },
        lName: {
            type: String,
            default: ''
        },
        email: {
            type: String,
            default: ''
        },
        noHP: {
            type: String,
            default: ''
        }
    },
    setup(props){
        return{
            props
        }
    }
};
</script>
