<template>
    <fragment>
        <footer>
            <div class = "row white pt-4 center" style="padding-bottom:1%">
                <b>Created By Tesalonika Abigail</b>
            </div>
        </footer> 
    </fragment>
</template>

<style lang="css" scoped>
    @import '~/style.css';
</style>

<script>
    export default {
        name: 'Footer'
    }
</script>