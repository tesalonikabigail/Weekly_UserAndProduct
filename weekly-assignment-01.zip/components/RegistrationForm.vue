<template>
    <fragment>
        <div class="container-fluid py-3" style="background-color: lightblue; height: 100vh; overflow: auto;">
            <b-modal class="font-title" ref="regis-modal" hide-footer>
                <!-- <template #modal-header="{ close }">
                    <b-button size="sm" variant="outline-danger" @click="hideModal" style="text-align: right;">Close</b-button>
                </template> -->
                <section v-if="cek">
                    <div class="d-block text-center">
                        <ModalRegisFail :errorList="err" />
                    </div>
                </section>

                <section v-else>
                    <div class="d-block text-center">
                        <ModalRegisSucc :fName="info.fName" :lName="info.lName" :email="info.email" :noHP="info.noHP" />
                    </div>
                </section>
                
                <!-- <b-button class="mt-3" variant="outline-danger" block @click="hideModal">Close</b-button> -->
            </b-modal>

            <div class="mx-auto my-auto" style="background-color: white; padding: 1.3%; border-radius: 15px; margin: auto; width: 80%; max-height: 100vh; box-shadow: 5px 5px 10px 1px grey;"> <!-- hori, verti, spread, blur, col -->
                <div class="container-fluid">
                    <div class="row" style="max-height: 100vh;">
                        <div class="col-lg-6">
                            <div class="h-100 picture">
                                <img class="d-none d-lg-block d-md-none d-sm-none" style="object-fit: cover; width: 100%; height: 90vh;" src="../aset/pict.png" />
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <h2 style="text-align: center; font-family: 'Labrada', serif;">Create New Account</h2> <hr>
                            <form id="regisForm" class="px-2" @submit="onSubmit" style="padding-top: 2%;">
                                <!-- <div class="form-group">
                                    <label for="fName">First Name</label>
                                    <input type="text" name="fName" class="form-control" id="fName" style="border-radius: 10px;"/> <-- name yg dikirim ke be || v-on:keypress="isAlphabet($event)"--
                                    <-- <span id="msgFName" style="color: red"></span> --
                                </div> -->

                                <b-input-group class="mb-3">
                                    <label for="fName" class="w-100" style="font-family: 'Lato', sans-serif;">First Name</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-user fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="text" name="fName" id="fName" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>

                                <b-input-group class="mb-3">
                                    <label for="lName" class="w-100" style="font-family: 'Lato', sans-serif;">Last Name</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-user fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="text" name="lName" id="lName" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>
                                
                                <b-input-group class="mb-3">
                                    <label for="email" class="w-100" style="font-family: 'Lato', sans-serif;">Email Address</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-envelope fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="email" name="email" id="email" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>

                                <b-input-group class="mb-3">
                                    <label for="noHP" class="w-100" style="font-family: 'Lato', sans-serif;">Phone Number</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-phone fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="tel" name="noHP" id="noHP" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>
                                
                                <b-input-group class="mb-3">
                                    <label for="pass" class="w-100" style="font-family: 'Lato', sans-serif;">Password</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-key fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="password" name="pass" id="pass" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>
                                
                                <b-input-group class="mb-4">
                                    <label for="confirmPass" class="w-100" style="font-family: 'Lato', sans-serif;">Confirm Password</label>
                                    <b-input-group-prepend>
                                        <span class="input-group-text" style="border-radius: 10px 0 0 10px; background-color: white;"><i class="fa fa-key fa-md"></i></span>
                                    </b-input-group-prepend>
                                    <b-form-input class="shadow-none" type="password" name="confirmPass" id="confirmPass" style="border-radius: 0 10px 10px 0;"></b-form-input>
                                </b-input-group>

                                <input id="btnSubmit" type="submit" class="btn btn-outline-info" value="Submit" style="width: 100%; margin-top: 1%; border-radius: 10px;"/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </fragment>
</template>

<script>
import ModalRegisSucc from './ModalRegisSucc.vue';
import ModalRegisFail from './ModalRegisFail.vue';
import { reqFields, minLength, maxLength, regexValid } from '../regisValidation.js';

export default {
    name: "RegisForm",
    components: {
        ModalRegisSucc,
        ModalRegisFail
    },
    data: function() {
        return ({
            err: [],
            info: {
                fName: "",
                lName: "",
                email: "",
                noHP: ""
            }
        })
    },
    methods: {
        showModal() {
            this.$refs['regis-modal'].show()
        },
        hideModal() {
            this.$refs['regis-modal'].hide()
        },
        onSubmit(e) {
            e.preventDefault();
            this.err = [];
            this.info = [];
            this.cek = false;

            let fName = document.getElementById("fName").value;
            let lName = document.getElementById("lName").value;
            let email = document.getElementById("email").value;
            let noHP = document.getElementById("noHP").value;
            let pass = document.getElementById("pass").value;
            let confirmPass = document.getElementById("confirmPass").value;

            // bawah ini engga
            // let msgFName = document.getElementById("msgFName");

            // msgFName.innerHTML = "";
            
            // if (fName == "" && lName == "" && email == "" && noHP == "" && pass == "" && confirmPass == ""){
            //     msgFName.innerHTML = "First Name Cannot Be Empty";
            //     return;
            // }
 
            // Required Fields
            // if (fName === "")
            //     this.errRequiredInput("First Name");

            (reqFields(fName, "First Name")) ? this.err.push(reqFields(fName, "First Name")) : "";
            (reqFields(lName, "Last Name")) ? this.err.push(reqFields(lName, "Last Name")) : "";
            (reqFields(email, "Email")) ? this.err.push(reqFields(email, "Email")) : "";
            (reqFields(noHP, "Phone Number")) ? this.err.push(reqFields(noHP, "Phone Number")) : "";
            (reqFields(pass, "Password")) ? this.err.push(reqFields(pass, "Password")) : "";
            (reqFields(confirmPass, "Confirm Password")) ? this.err.push(reqFields(confirmPass, "Confirm Password")) : "";

            // if(this.err.push(reqFields(fName, "First Name")));
            // if(this.err.push(reqFields(lName, "Last Name")));

            // Min Length
            // if (fName.length < 3)
            //     this.errMinLength("First Name", 3);

            (minLength(fName, 3, "First Name")) ? this.err.push(minLength(fName, 3, "First Name")) : "";
            (minLength(lName, 3, "Last Name")) ? this.err.push(minLength(lName, 3, "Last Name")) : "";
            (minLength(email, 10, "Email")) ? this.err.push(minLength(email, 10, "Email")) : "";
            (minLength(noHP, 10, "Phone Number")) ? this.err.push(minLength(noHP, 10, "Phone Number")) : "";
            (minLength(pass, 8, "Password")) ? this.err.push(minLength(pass, 8, "Password")) : "";
            (minLength(confirmPass, 8, "Confirm Password")) ? this.err.push(minLength(confirmPass, 8, "Confirm Password")) : "";

            // if(this.err.push(minLength(fName, 3, "First Name")));
            // if(this.err.push(minLength(lName, 3, "Last Name")));
            
            // Max Length
            // if (fName.length > 20)
            //     this.errMaxLength("First Name", 20);

            (maxLength(fName, 20, "First Name")) ? this.err.push(maxLength(fName, 20, "First Name")) : "";
            (maxLength(lName, 20, "Last Name")) ? this.err.push(maxLength(lName, 20, "Last Name")) : "";
            (maxLength(email, 30, "Email")) ? this.err.push(maxLength(email, 30, "Email")) : "";
            (maxLength(noHP, 16, "Phone Number")) ? this.err.push(maxLength(noHP, 16, "Phone Number")) : "";
            (maxLength(pass, 12, "Password")) ? this.err.push(maxLength(pass, 12, "Password")) : "";
            (maxLength(confirmPass, 12, "Confirm Password")) ? this.err.push(maxLength(confirmPass, 12, "Confirm Password")) : "";

            // if(this.err.push(maxLength(fName, 20, "First Name")));
            // if(this.err.push(maxLength(lName, 20, "Last Name")));
            
            if (pass !== confirmPass)
                this.err.push("Password and Confirm Password Must Be the Same");

            // Regex Validation
            (regexValid(fName, /^[A-Z]+$/i, "First Name", "(Include Only Alphabet)")) ? this.err.push(regexValid(fName, /^[A-Z]+$/i, "First Name", "(Include Only Alphabet)")) : "";
            (regexValid(lName, /^[A-Za-z]+$/, "Last Name", "(Include Only Alphabet)")) ? this.err.push(regexValid(lName, /^[A-Za-z]+$/, "Last Name", "(Include Only Alphabet)")) : "";
            (regexValid(email, /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, "Email", "No Space and Special Characters Except ('-', '.', '_')")) ? this.err.push(regexValid(email, /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, "Email", "")) : "";
            (regexValid(noHP, /^\d+$/, "Phone Number", "(Include Only Numbers)")) ? this.err.push(regexValid(noHP, /^\d+$/, "Phone Number", "(Include Only Numbers)")) : "";

            // if(this.err.push(regexValid(fName, /^[A-Z]+$/i, "First Name", "(Include Only Alphabet)")));
           
            // if (!(/^[A-Z]+$/i.test(fName)) && fName.length > 0)
            //     this.alphabetRegex("First Name");
            
            // this.removeItem();

            // Is error
            if (this.err.length > 0)
                this.cek = true;
            else {
                this.info.fName = fName;
                this.info.lName = lName;
                this.info.email = email;
                this.info.noHP = noHP;
                this.info.pass = pass;
                this.info.confirmPass = confirmPass;

                document.getElementById("regisForm").reset();
            }

            this.showModal();
        }
        // removeItem(){
        //     let i = 0;
        //     while (i < this.err.length){
        //         if (this.err[i] === "")
        //             this.err.splice(i, 1);
        //         else
        //             i++;
        //     }
        // }
    }
}
</script>