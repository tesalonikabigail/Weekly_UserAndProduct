<template>
    <fragment>
        <div id="aboutme" class="row white padding-32">
            <div class="row">
                <div class="col-lg-4 col-sm-12 center" style="float: left;">
                    <img class="img-responsive" style="width: 50%" src="../aset/foto.jpg" alt="profilePicture">
                </div>
                <div class = "col-lg-8 col-sm-12 pt-3" style = "float: left;">
                    <h2>Introduction</h2> <hr>
                    <p class="pt-2 textSize" style="padding-right: 10px">I'm currently a 3rd year Informatics student at Universitas Multimedia Nusantara. My interest as an Informatics student is developing websites, 
                        especially as a backend developer. I've worked as a backend developer for a project and college activities with CI3, Laravel9 and Express.js programming 
                        language before. Now I'm currently working as a Website Developer Intern at Global Loyalty Indonesia.</p>
                </div>
            </div>
        </div>
    </fragment>
</template>

<style lang="css" scoped>
    @import '~/style.css';
</style>

<script>
    export default {
        name: 'Introduction'
    }
</script>