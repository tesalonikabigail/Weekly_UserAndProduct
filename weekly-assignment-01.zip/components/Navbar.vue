<template>
    <fragment>
        <div id = "home" class="black">
            <div class = "center">
                <h1 style="margin-top:10px; color: #F5F5F5">Tesalonika Abigail</h1>
                <h4 style="color: #F5F5F5">Web Developer Intern at Global Loyalty Indonesia</h4>
            </div>
            <div class="row">
                <nav class="center navbar" style="padding-top: 20px; padding-bottom: 15px">
                    <li class="col-2"><a href="#home">Home</a></li>
                    <li class="col-2"><a href="#aboutme">About Me</a></li>
                    <li class="col-2"><a href="#experience">Experience</a></li>
                    <li class="col-2"><a href="#expDetail">Experience Detail</a></li>
                </nav>
            </div>
        </div>
    </fragment>
</template>

<style lang="css" scoped>
    @import '~/style.css';
</style>

<script>
    export default {
        name: 'Navbar'
    }
</script>