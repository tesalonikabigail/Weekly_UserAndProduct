<template>
    <fragment>
        <h3>Registration Failed!</h3> <hr>
        <p v-for="e in errorList" style="text-align: left; padding-left: 3%;">
            {{ e }}
        </p>
    </fragment>
</template>

<script>
export default {
    name: "ModalRegisFail",
    props: {
        errorList: {
            type: Array,
            default: []
        }
    },
    setup(props){
        return{
            props
        }
    }
}
</script>