<template>
    <fragment>
        <div id="aboutme" class="black font-white">
            <div class="padding-16 center" style="color: #F5F5F5">
                <h2 class="padding-16">Profile Details</h2>
                <div class="row center padding-16">
                    <div class="pt-4 center col-lg-3">
                        <i class="fa fa-user"></i>
                        <p class="pt-2">Tesalonika Abigail</p>
                    </div>
                    <div class="pt-4 center col-lg-3">
                        <i class="fa fa-id-card-o"></i>
                        <p class="">1023020371</p>
                    </div>
                    <div class="pt-4 center col-lg-3">
                        <i class="fa fa-envelope-o"></i>
                        <p>tesalonikabigail@gmail.com</p>
                    </div>
                    <div class="pt-4 center col-lg-3">
                        <i class="fa fa-phone"></i>
                        <p>0895-3225-18514</p>
                    </div>
                    <div class="col-3"></div>
                    <div class="pt-5 center col-3">
                        <i class="fa fa-linkedin-square"></i><br>
                        <a href="https://www.linkedin.com/in/tesalonika-abigail-22a48522a/" class="text-hov">Linkedin</a>
                    </div>
                    <div class="pt-5 center col-3">
                        <i class="fa fa-instagram"></i> <br>
                        <a href="instagram.com/tesalonikabigail" class="text-hov">Instagram</a>
                    </div>
                    <div class="col-3"></div>
                </div>
            </div>
        </div>
    </fragment>
</template>

<style lang="css" scoped>
    @import '~/style.css';
</style>

<script>
    export default {
        name: 'ProfDetail'
    }
</script>