import Vue from 'vue'
import Fragment from 'vue-fragment'

Vue.use(Fragment.Plugin)