export const reqFields = (item, msg) => {
    if(item === "")
        return `${msg} cannot Be Empty`;
    return false;
}

export const minLength = (item, min, msg) => {
    if(item.length < min)
        return msg + ' Must Be At Least ' + min + ' Characters';
    return false;
}

export const maxLength = (item, max, msg) => {
    if(item.length > max)
        return `${msg} Must Be Less Than ${max} Characters`;
    return false;
}

export const regexValid = (item, regex, msg, msg2) => {
    if(!(regex.test(item)) && item.length > 0)
        return `${msg} Input Must be Valid ${msg2}`;
    return false;
}

// exports.reqFields = function(item, msg){
//     console.log("Testing");
//     return function(req, res){
//         console.log("Testing");
//         if (req.body === "")
//             // return res.status(400).send("First Name Cannot be Empty");
//             console.log("Testing");
//     }
// }

// exports.reqFields = function(req, res) {
//     console.log("ini = " + req.body);
//     if (name.length === "")
//         // return res.status(400).send("First Name Cannot be Empty");
//         console.log("Testing2");   
// }
